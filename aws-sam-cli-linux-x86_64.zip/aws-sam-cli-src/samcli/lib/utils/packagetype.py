"""
Enums for determining packagetype of Lambda function.
"""

IMAGE = "Image"
ZIP = "Zip"
